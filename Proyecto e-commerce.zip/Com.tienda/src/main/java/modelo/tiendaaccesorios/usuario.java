/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.tiendaaccesorios;


public abstract class usuario {
    
    private int id;
    String nombre;
    private String contraseña;
    private String correo;

    public usuario(int id, String nombre, String contraseña, String correo) {
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
        this.contraseña = contraseña;

        
        
         }
    
    
    public abstract String getRol();
    
    public void mostrarInformacion(){
        
        System.out.println("ID "+ id);
        System.out.println("nombre"+ nombre);
        System.out.println("correo"+ correo);
        
    
        
        
}

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getContraseña() {
        return contraseña;
    }

    public String getCorreo() {
        return correo;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
    
    
}
