/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.excepciones;

public class CantidadInvalidaException extends Exception {

    public CantidadInvalidaException(String mensaje) {
        super(mensaje);
    }
}
