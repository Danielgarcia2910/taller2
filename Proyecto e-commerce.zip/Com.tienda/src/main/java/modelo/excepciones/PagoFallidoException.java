/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.excepciones;

public class PagoFallidoException extends Exception {

    public PagoFallidoException(String mensaje) {
        super(mensaje);
    }
}
