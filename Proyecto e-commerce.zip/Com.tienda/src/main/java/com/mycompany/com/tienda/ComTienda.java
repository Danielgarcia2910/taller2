/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.com.tienda;

import modelo.tiendaaccesorios.*;
import modelo.excepciones.*;
import java.util.ArrayList;

public class ComTienda {

    public static void main(String[] args) {

        System.out.println("==========================================");
        System.out.println("       TIENDA DE ACCESORIOS - DEMO       ");
        System.out.println("==========================================");

        // ── Inventario global del sistema ──────────────────────
        ArrayList<Producto> inventario = new ArrayList<>();

        // ──────────────────────────────────────────────────────
        // ESCENARIO 1: Crear administrador y agregar productos
        // ──────────────────────────────────────────────────────
        System.out.println("\n--- ESCENARIO 1: Administrador agrega productos ---");

        Administrador admin = new Administrador(
                1, "Carlos Lopez", "carlos@tienda.com", "admin123");

        admin.mostrarInformacion();
        System.out.println("Rol: " + admin.getRol());

        Producto gafasdesol   = new Producto("gafas de sol",   25000, 10, "accesorio");
        Producto collar = new Producto("collar", 120000, 5, "joyeria");
        Producto pulsera = new Producto("pulsera",    100000, 20, "joyeria");
        Producto gorra    = new Producto("gorras",     18000,  0, "accesorio"); // sin stock

        admin.agregarProducto(inventario, gafasdesol);
        admin.agregarProducto(inventario, collar);
        admin.agregarProducto(inventario, pulsera);
        admin.agregarProducto(inventario, gorra);

        System.out.println("\nInventario actual:");
        for (Producto p : inventario) {
            p.mostrarInformacion();
            System.out.println("Disponible: " + p.disponible());
            System.out.println("---");
        }

        // ──────────────────────────────────────────────────────
        // ESCENARIO 2: Administrador elimina un producto
        // ──────────────────────────────────────────────────────
        System.out.println("\n--- ESCENARIO 2: Administrador elimina producto ---");

        try {
            admin.eliminarProducto(inventario, gorra);
        } catch (ProductoNoEncontradoException e) {
            System.out.println("Error: " + e.getMessage());
        }

        // Intentar eliminar un producto que no existe
        Producto productoFalso = new Producto("Producto Falso", 0, 0, "Ninguno");
        try {
            admin.eliminarProducto(inventario, productoFalso);
        } catch (ProductoNoEncontradoException e) {
            System.out.println("Excepcion capturada -> " + e.getMessage());
        }

        // ──────────────────────────────────────────────────────
        // ESCENARIO 3: Crear cliente
        // ──────────────────────────────────────────────────────
        System.out.println("\n--- ESCENARIO 3: Registro de cliente ---");

        Cliente cliente = new Cliente(
                2, "Ana Martinez", "ana@correo.com", "clave456",
                "Calle 45 #12-30", "3001234567");

        cliente.mostrarInformacion();
        System.out.println("Rol: " + cliente.getRol());
        System.out.println(cliente);

        // ──────────────────────────────────────────────────────
        // ESCENARIO 4: Cliente agrega productos al carrito
        // ──────────────────────────────────────────────────────
        System.out.println("\n--- ESCENARIO 4: Cliente agrega al carrito ---");

        Carrito carrito = new Carrito(cliente);

        carrito.agregarProducto(gafasdesol);
        carrito.agregarProducto(collar);
        carrito.agregarProducto(pulsera);

        try {
            carrito.mostrarCarrito();
        } catch (CarritoVacioException e) {
            System.out.println("Error: " + e.getMessage());
        }

        // ──────────────────────────────────────────────────────
        // ESCENARIO 5: Carrito vacío lanza excepción
        // ──────────────────────────────────────────────────────
        System.out.println("\n--- ESCENARIO 5: Carrito vacio lanza excepcion ---");

        Carrito carritoVacio = new Carrito(cliente);
        try {
            carritoVacio.mostrarCarrito();
        } catch (CarritoVacioException e) {
            System.out.println("Excepcion capturada -> " + e.getMessage());
        }

        try {
            double totalVacio = carritoVacio.calcularTotal();
        } catch (CarritoVacioException e) {
            System.out.println("Excepcion capturada -> " + e.getMessage());
        }

        // ──────────────────────────────────────────────────────
        // ESCENARIO 6: Comprar producto exitosamente
        // ──────────────────────────────────────────────────────
        System.out.println("\n--- ESCENARIO 6: Comprar producto (exitoso) ---");

        try {
            System.out.println("Stock antes: " + gafasdesol.getStock());
            gafasdesol.comprar(2);
            System.out.println("Compra exitosa. Stock despues: " + gafasdesol.getStock());
        } catch (StockInsuficienteException | CantidadInvalidaException e) {
            System.out.println("Error: " + e.getMessage());
        }

        // ──────────────────────────────────────────────────────
        // ESCENARIO 7: Comprar con cantidad invalida (cantidad <= 0)
        // ──────────────────────────────────────────────────────
        System.out.println("\n--- ESCENARIO 7: Cantidad invalida ---");

        try {
            pulsera.comprar(-5);
        } catch (CantidadInvalidaException e) {
            System.out.println("Excepcion capturada -> " + e.getMessage());
        } catch (StockInsuficienteException e) {
            System.out.println("Error: " + e.getMessage());
        }

        try {
            pulsera.comprar(0);
        } catch (CantidadInvalidaException e) {
            System.out.println("Excepcion capturada -> " + e.getMessage());
        } catch (StockInsuficienteException e) {
            System.out.println("Error: " + e.getMessage());
        }

        // ──────────────────────────────────────────────────────
        // ESCENARIO 8: Comprar con stock insuficiente
        // ──────────────────────────────────────────────────────
        System.out.println("\n--- ESCENARIO 8: Stock insuficiente ---");

        try {
            collar.comprar(100); // solo hay 5 en stock
        } catch (StockInsuficienteException e) {
            System.out.println("Excepcion capturada -> " + e.getMessage());
            System.out.println("Stock actual de los collares: " + collar.getStock());
        } catch (CantidadInvalidaException e) {
            System.out.println("Error: " + e.getMessage());
        }

        // ──────────────────────────────────────────────────────
        // ESCENARIO 9: Crear pedido y verlo en historial
        // ──────────────────────────────────────────────────────
        System.out.println("\n--- ESCENARIO 9: Crear pedido ---");

        ArrayList<Producto> productosDelPedido = new ArrayList<>();
        productosDelPedido.add(gafasdesol);
        productosDelPedido.add(pulsera);

        try {
            Pedido pedido1 = new Pedido(1001, cliente, productosDelPedido);
            pedido1.mostrarPedido();
            cliente.agregarPedido(pedido1);
        } catch (CarritoVacioException e) {
            System.out.println("Error al crear pedido: " + e.getMessage());
        }

        // ──────────────────────────────────────────────────────
        // ESCENARIO 10: Pedido vacio lanza excepcion
        // ──────────────────────────────────────────────────────
        System.out.println("\n--- ESCENARIO 10: Pedido vacio lanza excepcion ---");

        ArrayList<Producto> listaVacia = new ArrayList<>();
        try {
            Pedido pedidoVacio = new Pedido(1002, cliente, listaVacia);
        } catch (CarritoVacioException e) {
            System.out.println("Excepcion capturada -> " + e.getMessage());
        }

        // ──────────────────────────────────────────────────────
        // ESCENARIO 11: Historial de pedidos del cliente
        // ──────────────────────────────────────────────────────
        System.out.println("\n--- ESCENARIO 11: Historial de pedidos ---");

        cliente.mostrarHistorial();

        // Cliente sin pedidos
        Cliente cliente2 = new Cliente(
                3, "Pedro Ramirez", "pedro@correo.com", "clave789",
                "Carrera 10 #5-20", "3109876543");
        cliente2.mostrarHistorial(); // debe mostrar "No tienes pedidos registrados"

        // ──────────────────────────────────────────────────────
        // ESCENARIO 12: Vaciar carrito
        // ──────────────────────────────────────────────────────
        System.out.println("\n--- ESCENARIO 12: Vaciar carrito ---");

        carrito.vaciarCarrito();
        try {
            carrito.mostrarCarrito();
        } catch (CarritoVacioException e) {
            System.out.println("Excepcion capturada -> " + e.getMessage());
        }

        // ──────────────────────────────────────────────────────
        // ESCENARIO 13: Eliminar producto del carrito
        // ──────────────────────────────────────────────────────
        System.out.println("\n--- ESCENARIO 13: Eliminar producto del carrito ---");

        Carrito carrito2 = new Carrito(cliente2);
        carrito2.agregarProducto(collar);
        carrito2.agregarProducto(pulsera);

        try {
            carrito2.eliminarProducto(collar);
            carrito2.mostrarCarrito();
        } catch (ProductoNoEncontradoException | CarritoVacioException e) {
            System.out.println("Error: " + e.getMessage());
        }

        // Intentar eliminar un producto que no está en el carrito
        try {
            carrito2.eliminarProducto(gafasdesol); // funda no fue agregada a carrito2
        } catch (ProductoNoEncontradoException e) {
            System.out.println("Excepcion capturada -> " + e.getMessage());
        }

        System.out.println("\n==========================================");
        System.out.println("           DEMO FINALIZADA               ");
        System.out.println("==========================================");
    }
}