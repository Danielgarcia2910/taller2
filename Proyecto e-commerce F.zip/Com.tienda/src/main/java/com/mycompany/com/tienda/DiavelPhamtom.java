package com.mycompany.com.tienda;

import modelo.tiendaaccesorios.*;
import modelo.excepciones.*;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.ArrayList;

public class DiavelPhamtom extends JFrame {

    // -- Colores ----------------------------------------------------
    private static final Color PURPLE       = new Color(109, 40, 217);
    private static final Color PURPLE_LIGHT = new Color(237, 233, 254);
    private static final Color PURPLE_DARK  = new Color(76, 29, 149);
    private static final Color GREEN        = new Color(22, 163, 74);
    private static final Color RED          = new Color(220, 38, 38);
    private static final Color BG           = new Color(249, 250, 251);
    private static final Color WHITE        = Color.WHITE;
    private static final Color TEXT_DARK    = new Color(17, 24, 39);
    private static final Color TEXT_GRAY    = new Color(107, 114, 128);
    private static final Color BORDER_CLR   = new Color(229, 231, 235);

    // -- Modelo -----------------------------------------------------
    private Cliente     cliente;
    private Administrador admin;
    private final ArrayList<Producto> inventario = new ArrayList<>();
    private Carrito     carrito;

    // -- Estado de sesion ------------------------------------------
    private boolean esAdmin = false;
    private String  categoriaActual = "Todos";

    private JPanel panelProductos;
    private JPanel panelCarritoItems;
    private JLabel lblTotal;
    private JLabel lblContadorCarrito;
    private JTextField txtBuscar;
    private JLabel     lblRolHeader;
    private JLabel     lblNombreHeader;
    private JPanel     panelSidebar;
    private JPanel     rootCenter;

    // =====================================================================
    public DiavelPhamtom() {
        cliente = new Cliente(1, "Cliente Juan", "juan@mail.com", "1234",
                              "Calle 45 #12-30", "3001234567");
        admin   = new Administrador(99, "Administrador", "admin@tienda.com", "admin");
        carrito = new Carrito(cliente);

        // Productos accesorios de moda
        inventario.add(new Producto("Gafas Sol Wayfarers",   85000, 15, "Gafas"));
        inventario.add(new Producto("Gafas Sol Aviator",    120000, 10, "Gafas"));
        inventario.add(new Producto("Collar Perlas",         55000, 20, "Collares"));
        inventario.add(new Producto("Collar Dorado Fino",    42000, 18, "Collares"));
        inventario.add(new Producto("Gorra Cap Negra",       38000, 25, "Gorras"));
        inventario.add(new Producto("Gorra Trucker Blanca",  35000, 12, "Gorras"));
        inventario.add(new Producto("Pulsera Tejida",        22000, 30, "Pulseras"));
        inventario.add(new Producto("Pulsera Oro Rosado",    65000,  8, "Pulseras"));
        inventario.add(new Producto("Anillo Plata 925",      48000, 14, "Anillos"));
        inventario.add(new Producto("Anillo Dorado Fino",    52000, 10, "Anillos"));
        inventario.add(new Producto("Reloj Clasico Negro",  185000,  6, "Relojes"));
        inventario.add(new Producto("Reloj Minimalista",    220000,  4, "Relojes"));

        configurarVentana();
        construirUI();
        setVisible(true);
    }

    // =====================================================================
    private void configurarVentana() {
        setTitle("Diavel Phantom");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1300, 820);
        setLocationRelativeTo(null);
    }

    // =====================================================================
    // VENTANA PRINCIPAL
    // =====================================================================
    private void construirUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG);
        root.add(crearHeader(), BorderLayout.NORTH);

        rootCenter = new JPanel(new BorderLayout());
        rootCenter.setBackground(BG);
        rootCenter.add(crearSidebar(),      BorderLayout.WEST);
        rootCenter.add(crearCentro(),       BorderLayout.CENTER);
        rootCenter.add(crearPanelCarrito(), BorderLayout.EAST);

        root.add(rootCenter, BorderLayout.CENTER);
        setContentPane(root);
    }

    // =====================================================================
    // PARTE DE ARRIBA
    // =====================================================================
    private JPanel crearHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(WHITE);
        header.setBorder(BorderFactory.createCompoundBorder(
            new MatteBorder(0, 0, 1, 0, BORDER_CLR),
            new EmptyBorder(14, 24, 14, 24)));
        header.setPreferredSize(new Dimension(0, 75));

        // Logo
        JPanel logoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        logoPanel.setOpaque(false);
        JLabel icono = new JLabel("\uD83D\uDED2");
        icono.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 32));
        JPanel textos = new JPanel(new GridLayout(2, 1));
        textos.setOpaque(false);
        JLabel titulo = new JLabel("Diavel Phantom");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(PURPLE);
        JLabel sub = new JLabel("Encuentra los mejores accesorios de moda");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        sub.setForeground(TEXT_GRAY);
        textos.add(titulo); textos.add(sub);
        logoPanel.add(icono); logoPanel.add(textos);

        // Usuario y boton cambiar rol
        JPanel userPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        userPanel.setOpaque(false);

        // Boton cambiar a Admin / Cliente
        JButton btnCambiarRol = crearBotonSecundario("\uD83D\uDD04 Cambiar a Admin");
        btnCambiarRol.addActionListener(e -> cambiarRol(btnCambiarRol));
        userPanel.add(btnCambiarRol);

        JPanel userTexts = new JPanel(new GridLayout(2, 1));
        userTexts.setOpaque(false);
        lblNombreHeader = new JLabel("Bienvenido, " + cliente.getNombre());
        lblNombreHeader.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblNombreHeader.setHorizontalAlignment(SwingConstants.RIGHT);
        lblRolHeader = new JLabel("Rol: " + cliente.getRol());
        lblRolHeader.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblRolHeader.setForeground(TEXT_GRAY);
        lblRolHeader.setHorizontalAlignment(SwingConstants.RIGHT);
        userTexts.add(lblNombreHeader); userTexts.add(lblRolHeader);

        JLabel avatar = new JLabel("\uD83D\uDC64");
        avatar.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));
        userPanel.add(userTexts); userPanel.add(avatar);

        header.add(logoPanel, BorderLayout.WEST);
        header.add(userPanel, BorderLayout.EAST);
        return header;
    }

    // =====================================================================
    // CAMBIAR ROL ADMIN / CLIENTE
    // =====================================================================
    private void cambiarRol(JButton btn) {
        esAdmin = !esAdmin;
        if (esAdmin) {
            // Pedir contrasena
            JPasswordField pass = new JPasswordField();
            int ok = JOptionPane.showConfirmDialog(this, pass,
                "Ingresa la contrasena de administrador:", JOptionPane.OK_CANCEL_OPTION);
            if (ok != JOptionPane.OK_OPTION ||
                !new String(pass.getPassword()).equals("admin")) {
                esAdmin = false;
                JOptionPane.showMessageDialog(this,
                    "\u274C Contrasena incorrecta.", "Acceso denegado",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (btn != null) btn.setText("\uD83D\uDD04 Cambiar a Cliente");
            lblNombreHeader.setText("Bienvenido, " + admin.getNombre());
            lblRolHeader.setText("Rol: " + admin.getRol());
        } else {
            if (btn != null) btn.setText("\uD83D\uDD04 Cambiar a Admin");
            lblNombreHeader.setText("Bienvenido, " + cliente.getNombre());
            lblRolHeader.setText("Rol: " + cliente.getRol());
        }
        // Reconstruir sidebar y panel derecho segun el rol
        rootCenter.removeAll();
        rootCenter.add(crearSidebar(),      BorderLayout.WEST);
        rootCenter.add(crearCentro(),       BorderLayout.CENTER);
        if (!esAdmin) rootCenter.add(crearPanelCarrito(), BorderLayout.EAST);
        rootCenter.revalidate();
        rootCenter.repaint();
        actualizarProductos();
    }

    // =====================================================================
    // PARTE LATERAL
    // =====================================================================
    private JPanel crearSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(WHITE);
        sidebar.setBorder(BorderFactory.createCompoundBorder(
            new MatteBorder(0, 0, 0, 1, BORDER_CLR),
            new EmptyBorder(16, 0, 16, 0)));
        sidebar.setPreferredSize(new Dimension(220, 0));

        // Menu diferente segun rol
        if (esAdmin) {
            // Menu Administrador
            String[][] menuAdmin = {
                {"\uD83D\uDCE6", "Agregar Producto"},
                {"\uD83D\uDDD1", "Eliminar Producto"},
                {"\u270F\uFE0F", "Editar Precio"},
                {"\uD83D\uDCCA", "Editar Stock"},
                {"\uD83D\uDD04", "Cambiar a Cliente"},
                {"\uD83D\uDEAA", "Cerrar Sesion"}
            };
            for (String[] item : menuAdmin) {
                JButton btn = crearBotonMenuSimple(item[0], item[1]);
                btn.addActionListener(e -> manejarMenuAdmin(item[1]));
                sidebar.add(btn);
            }
        } else {
            // Menu Cliente
            String[][] menuCliente = {
                {"\uD83C\uDFE0", "Inicio"},
                {"\uD83D\uDCCB", "Mis Pedidos"},
                {"\uD83D\uDC64", "Perfil"},
                {"\uD83D\uDD04", "Cambiar a Admin"},
                {"\uD83D\uDEAA", "Cerrar Sesion"}
            };
            for (String[] item : menuCliente) {
                JButton btn = crearBotonMenuSimple(item[0], item[1]);
                btn.addActionListener(e -> manejarMenuCliente(item[1]));
                sidebar.add(btn);
            }

            sidebar.add(Box.createVerticalStrut(20));

            // Categorias
            JLabel lblCat = new JLabel("  Categorias");
            lblCat.setFont(new Font("Segoe UI", Font.BOLD, 13));
            lblCat.setForeground(PURPLE);
            lblCat.setBorder(new EmptyBorder(6, 16, 6, 16));
            sidebar.add(lblCat);

            String[] categorias = {"Todos","Gafas","Collares","Gorras","Pulseras","Anillos","Relojes"};
            ButtonGroup grupoCat = new ButtonGroup();
            for (String cat : categorias) {
                JToggleButton rb = crearBotonCategoria(cat);
                grupoCat.add(rb);
                if (cat.equals(categoriaActual)) rb.setSelected(true);
                rb.addActionListener(e -> {
                    categoriaActual = cat;
                    actualizarProductos();
                });
                sidebar.add(rb);
            }
        }

        sidebar.add(Box.createVerticalGlue());
        return sidebar;
    }

    // =====================================================================
    // CONTROLADORES
    // =====================================================================
    private void manejarMenuCliente(String opcion) {
        switch (opcion) {
            case "Mis Pedidos"     -> verHistorial();
            case "Perfil"          -> verPerfil();
            case "Cambiar a Admin" -> cambiarRol(null);
            case "Cerrar Sesion"   -> confirmarSalir();
        }
    }

    private void manejarMenuAdmin(String opcion) {
        switch (opcion) {
            case "Agregar Producto"  -> agregarProductoAdmin();
            case "Eliminar Producto" -> eliminarProductoAdmin();
            case "Editar Precio"     -> editarPrecioAdmin();
            case "Editar Stock"      -> editarStockAdmin();
            case "Cambiar a Cliente" -> cambiarRol(null);
            case "Cerrar Sesion"     -> confirmarSalir();
        }
    }

    // =====================================================================
    // ACCIONES ADMIN
    // =====================================================================
    private void agregarProductoAdmin() {
        JTextField nombre  = new JTextField();
        JTextField precio  = new JTextField();
        JTextField stock   = new JTextField();
        String[]   tipos   = {"Gafas","Collares","Gorras","Pulseras","Anillos","Relojes"};
        JComboBox<String> tipo = new JComboBox<>(tipos);

        JPanel form = new JPanel(new GridLayout(8, 1, 4, 4));
        form.add(new JLabel("Nombre:")); form.add(nombre);
        form.add(new JLabel("Precio:")); form.add(precio);
        form.add(new JLabel("Stock:"));  form.add(stock);
        form.add(new JLabel("Tipo:"));   form.add(tipo);

        int r = JOptionPane.showConfirmDialog(this, form,
            "Agregar Producto", JOptionPane.OK_CANCEL_OPTION);
        if (r != JOptionPane.OK_OPTION) return;

        try {
            Producto nuevo = new Producto(
                nombre.getText().trim(),
                Double.parseDouble(precio.getText().trim()),
                Integer.parseInt(stock.getText().trim()),
                (String) tipo.getSelectedItem());
            admin.agregarProducto(inventario, nuevo);
            actualizarProductos();
            JOptionPane.showMessageDialog(this,
                "\u2705 Producto \"" + nuevo.getNombre() + "\" agregado.",
                "Exito", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                "\u274C Precio y stock deben ser numeros.",
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarProductoAdmin() {
        if (inventario.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay productos en el inventario.");
            return;
        }
        String[] nombres = inventario.stream()
            .map(Producto::getNombre).toArray(String[]::new);
        String sel = (String) JOptionPane.showInputDialog(this,
            "Selecciona el producto a eliminar:",
            "Eliminar Producto", JOptionPane.PLAIN_MESSAGE,
            null, nombres, nombres[0]);
        if (sel == null) return;

        inventario.stream()
            .filter(p -> p.getNombre().equals(sel))
            .findFirst()
            .ifPresent(p -> {
                try {
                    admin.eliminarProducto(inventario, p);
                    actualizarProductos();
                    JOptionPane.showMessageDialog(this,
                        "\u2705 Producto \"" + sel + "\" eliminado.",
                        "Exito", JOptionPane.INFORMATION_MESSAGE);
                } catch (ProductoNoEncontradoException ex) {
                    JOptionPane.showMessageDialog(this,
                        "\u274C " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            });
    }

    private void editarPrecioAdmin() {
        if (inventario.isEmpty()) return;
        String[] nombres = inventario.stream()
            .map(Producto::getNombre).toArray(String[]::new);
        String sel = (String) JOptionPane.showInputDialog(this,
            "Selecciona el producto:",
            "Editar Precio", JOptionPane.PLAIN_MESSAGE,
            null, nombres, nombres[0]);
        if (sel == null) return;

        inventario.stream().filter(p -> p.getNombre().equals(sel)).findFirst()
            .ifPresent(p -> {
                String nuevoPrecio = JOptionPane.showInputDialog(this,
                    "Precio actual: $" + String.format("%,.0f", p.getPrecio()) +
                    "\nIngresa el nuevo precio:",
                    String.valueOf((int) p.getPrecio()));
                if (nuevoPrecio == null) return;
                try {
                    p.setPrecio(Double.parseDouble(nuevoPrecio.trim()));
                    actualizarProductos();
                    JOptionPane.showMessageDialog(this,
                        "\u2705 Precio actualizado a $" +
                        String.format("%,.0f", p.getPrecio()),
                        "Exito", JOptionPane.INFORMATION_MESSAGE);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this,
                        "\u274C Ingresa un numero valido.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            });
    }

    private void editarStockAdmin() {
        if (inventario.isEmpty()) return;
        String[] nombres = inventario.stream()
            .map(Producto::getNombre).toArray(String[]::new);
        String sel = (String) JOptionPane.showInputDialog(this,
            "Selecciona el producto:",
            "Editar Stock", JOptionPane.PLAIN_MESSAGE,
            null, nombres, nombres[0]);
        if (sel == null) return;

        inventario.stream().filter(p -> p.getNombre().equals(sel)).findFirst()
            .ifPresent(p -> {
                String nuevoStock = JOptionPane.showInputDialog(this,
                    "Stock actual: " + p.getStock() +
                    "\nIngresa el nuevo stock:",
                    String.valueOf(p.getStock()));
                if (nuevoStock == null) return;
                try {
                    int s = Integer.parseInt(nuevoStock.trim());
                    if (s < 0) throw new NumberFormatException();
                    p.setStock(s);
                    actualizarProductos();
                    JOptionPane.showMessageDialog(this,
                        "\u2705 Stock actualizado a " + p.getStock() + " unidades.",
                        "Exito", JOptionPane.INFORMATION_MESSAGE);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this,
                        "\u274C Ingresa un numero entero positivo.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            });
    }

    // =====================================================================
    // PANEL CENTRAL (productos)
    // =====================================================================
    private JPanel crearCentro() {
        JPanel centro = new JPanel(new BorderLayout(0, 0));
        centro.setBackground(BG);
        centro.setBorder(new EmptyBorder(16, 16, 16, 16));

        JPanel topBar = new JPanel(new BorderLayout(16, 0));
        topBar.setOpaque(false);
        topBar.setBorder(new EmptyBorder(0, 0, 14, 0));

        JLabel lblProductos = new JLabel("Productos");
        lblProductos.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblProductos.setForeground(TEXT_DARK);

        // Buscador
        JPanel buscadorPanel = new JPanel(new BorderLayout(6, 0));
        buscadorPanel.setBackground(WHITE);
        buscadorPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(BORDER_CLR, 1, true),
            new EmptyBorder(8, 14, 8, 14)));
        buscadorPanel.setPreferredSize(new Dimension(260, 38));
        txtBuscar = new JTextField();
        txtBuscar.setBorder(null);
        txtBuscar.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtBuscar.setForeground(TEXT_GRAY);
        txtBuscar.setText("Buscar producto...");
        txtBuscar.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (txtBuscar.getText().equals("Buscar producto...")) txtBuscar.setText("");
            }
            public void focusLost(FocusEvent e) {
                if (txtBuscar.getText().isEmpty()) txtBuscar.setText("Buscar producto...");
            }
        });
        txtBuscar.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) { actualizarProductos(); }
        });
        buscadorPanel.add(txtBuscar, BorderLayout.CENTER);
        buscadorPanel.add(new JLabel("\uD83D\uDD0D"), BorderLayout.EAST);

        topBar.add(lblProductos,  BorderLayout.WEST);
        topBar.add(buscadorPanel, BorderLayout.EAST);

        panelProductos = new JPanel(new GridLayout(0, 3, 12, 12));
        panelProductos.setOpaque(false);
        JScrollPane scroll = new JScrollPane(panelProductos);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.getVerticalScrollBar().setUnitIncrement(16);

        centro.add(topBar, BorderLayout.NORTH);
        centro.add(scroll, BorderLayout.CENTER);

        actualizarProductos();
        return centro;
    }

    // =====================================================================
    // TARJETA DE PRODUCTO
    // =====================================================================
    private JPanel crearTarjetaProducto(Producto p) {
        JPanel card = new JPanel(new BorderLayout(0, 6));
        card.setBackground(WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(BORDER_CLR, 1, true),
            new EmptyBorder(14, 14, 14, 14)));

        // Emojis: Collares=📿  Pulseras=📿  Relojes=⌚
        String emoji = switch (p.getTipo()) {
            case "Gafas"    -> "\uD83D\uDD76";
            case "Collares" -> "\uD83D\uDCFF";
            case "Gorras"   -> "\uD83E\uDDE2";
            case "Pulseras" -> "\uD83D\uDCFF";
            case "Anillos"  -> "\uD83D\uDC8D";
            case "Relojes"  -> "\u231A";
            default         -> "\uD83D\uDED2";
        };

        JLabel imgLabel = new JLabel(emoji, SwingConstants.CENTER);
        imgLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 48));
        imgLabel.setPreferredSize(new Dimension(0, 90));

        JPanel infoPanel = new JPanel(new GridLayout(3, 1, 0, 2));
        infoPanel.setOpaque(false);
        JLabel nombre = new JLabel(p.getNombre());
        nombre.setFont(new Font("Segoe UI", Font.BOLD, 13));
        nombre.setForeground(TEXT_DARK);
        JLabel tipo = new JLabel(p.getTipo());
        tipo.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        tipo.setForeground(TEXT_GRAY);

        JPanel precioStock = new JPanel(new BorderLayout());
        precioStock.setOpaque(false);
        JLabel precio = new JLabel("$" + String.format("%,.0f", p.getPrecio()));
        precio.setFont(new Font("Segoe UI", Font.BOLD, 14));
        precio.setForeground(PURPLE);
        JLabel stock = new JLabel("Stock: " + p.getStock());
        stock.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        stock.setForeground(p.getStock() > 0 ? GREEN : RED);
        precioStock.add(precio, BorderLayout.WEST);
        precioStock.add(stock,  BorderLayout.EAST);

        infoPanel.add(nombre); infoPanel.add(tipo); infoPanel.add(precioStock);

        card.add(imgLabel,  BorderLayout.NORTH);
        card.add(infoPanel, BorderLayout.CENTER);

        // Si es admin: botones editar precio y stock inline
        if (esAdmin) {
            JPanel adminBtns = new JPanel(new GridLayout(1, 2, 6, 0));
            adminBtns.setOpaque(false);
            adminBtns.setBorder(new EmptyBorder(6, 0, 0, 0));

            JButton btnPrecio = crearBotonPrimario("\uD83D\uDCB2 Precio");
            JButton btnStock  = crearBotonSecundario("\uD83D\uDCCA Stock");

            btnPrecio.setPreferredSize(new Dimension(0, 34));
            btnStock.setPreferredSize(new Dimension(0, 34));

            btnPrecio.addActionListener(e -> {
                String nuevo = JOptionPane.showInputDialog(this,
                    "Precio actual: $" + String.format("%,.0f", p.getPrecio()) +
                    "\nNuevo precio:",
                    String.valueOf((int) p.getPrecio()));
                if (nuevo == null) return;
                try {
                    p.setPrecio(Double.parseDouble(nuevo.trim()));
                    actualizarProductos();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "\u274C Numero invalido.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            });

            btnStock.addActionListener(e -> {
                String nuevo = JOptionPane.showInputDialog(this,
                    "Stock actual: " + p.getStock() + "\nNuevo stock:",
                    String.valueOf(p.getStock()));
                if (nuevo == null) return;
                try {
                    int s = Integer.parseInt(nuevo.trim());
                    if (s < 0) throw new NumberFormatException();
                    p.setStock(s);
                    actualizarProductos();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "\u274C Numero entero positivo requerido.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            });

            adminBtns.add(btnPrecio);
            adminBtns.add(btnStock);
            card.add(adminBtns, BorderLayout.SOUTH);
        } else {
            // Cliente: boton agregar
            JButton btnAgregar = crearBotonPrimario("\uD83D\uDED2  Agregar");
            btnAgregar.setEnabled(p.getStock() > 0);
            btnAgregar.addActionListener(e -> agregarAlCarrito(p));
            card.add(btnAgregar, BorderLayout.SOUTH);
        }

        return card;
    }

    // =====================================================================
    // PANEL CARRITO (solo vista cliente)
    // =====================================================================
    private JPanel crearPanelCarrito() {
        JPanel panel = new JPanel(new BorderLayout(0, 12));
        panel.setBackground(WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
            new MatteBorder(0, 1, 0, 0, BORDER_CLR),
            new EmptyBorder(16, 16, 16, 16)));
        panel.setPreferredSize(new Dimension(290, 0));

        // Titulo
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        titlePanel.setOpaque(false);
        JLabel carritoTitle = new JLabel("\uD83D\uDED2  Carrito de Compras");
        carritoTitle.setFont(new Font("Segoe UI", Font.BOLD, 15));
        carritoTitle.setForeground(PURPLE);
        lblContadorCarrito = new JLabel("0");
        lblContadorCarrito.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lblContadorCarrito.setForeground(WHITE);
        lblContadorCarrito.setBackground(PURPLE);
        lblContadorCarrito.setOpaque(true);
        lblContadorCarrito.setBorder(new EmptyBorder(2, 7, 2, 7));
        titlePanel.add(carritoTitle);
        titlePanel.add(lblContadorCarrito);

        // Items
        panelCarritoItems = new JPanel();
        panelCarritoItems.setLayout(new BoxLayout(panelCarritoItems, BoxLayout.Y_AXIS));
        panelCarritoItems.setOpaque(false);
        JScrollPane scrollCarrito = new JScrollPane(panelCarritoItems);
        scrollCarrito.setBorder(null);
        scrollCarrito.setOpaque(false);
        scrollCarrito.getViewport().setOpaque(false);

        // Total
        JPanel totalPanel = new JPanel(new BorderLayout());
        totalPanel.setOpaque(false);
        totalPanel.setBorder(BorderFactory.createCompoundBorder(
            new MatteBorder(1, 0, 0, 0, BORDER_CLR),
            new EmptyBorder(10, 0, 10, 0)));
        JLabel lblTotalText = new JLabel("Total:");
        lblTotalText.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblTotal = new JLabel("$0");
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTotal.setForeground(PURPLE);
        totalPanel.add(lblTotalText, BorderLayout.WEST);
        totalPanel.add(lblTotal,     BorderLayout.EAST);

        // Boton realizar pedido
        JButton btnPedido = crearBotonVerde("\uD83D\uDCCB  Realizar Pedido");
        btnPedido.setPreferredSize(new Dimension(0, 42));
        btnPedido.addActionListener(e -> realizarPedido());

        // Acciones rapidas
        JLabel lblAcciones = new JLabel("Acciones Rapidas");
        lblAcciones.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblAcciones.setForeground(PURPLE);
        lblAcciones.setBorder(new EmptyBorder(10, 0, 6, 0));

        JPanel accionesPanel = new JPanel(new GridLayout(1, 2, 8, 0));
        accionesPanel.setOpaque(false);
        JButton btnHistorial = crearBotonSecundario("\uD83D\uDCCB Mis Pedidos");
        JButton btnPerfil    = crearBotonSecundario("\uD83D\uDC64 Perfil");
        btnHistorial.addActionListener(e -> verHistorial());
        btnPerfil.addActionListener(e -> verPerfil());
        accionesPanel.add(btnHistorial);
        accionesPanel.add(btnPerfil);

        JPanel sur = new JPanel(new BorderLayout(0, 6));
        sur.setOpaque(false);
        JPanel surTop = new JPanel(new BorderLayout(0, 8));
        surTop.setOpaque(false);
        surTop.add(totalPanel,  BorderLayout.NORTH);
        surTop.add(btnPedido,   BorderLayout.CENTER);
        sur.add(surTop,         BorderLayout.NORTH);
        sur.add(lblAcciones,    BorderLayout.CENTER);
        sur.add(accionesPanel,  BorderLayout.SOUTH);

        panel.add(titlePanel,    BorderLayout.NORTH);
        panel.add(scrollCarrito, BorderLayout.CENTER);
        panel.add(sur,           BorderLayout.SOUTH);

        actualizarCarritoUI();
        return panel;
    }

    private JPanel crearItemCarrito(Producto p) {
        JPanel item = new JPanel(new BorderLayout(8, 4));
        item.setBackground(WHITE);
        item.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(BORDER_CLR, 1, true),
            new EmptyBorder(8, 8, 8, 8)));
        item.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));

        // Emojis: Collares=📿  Pulseras=📿  Relojes=⌚
        String emoji = switch (p.getTipo()) {
            case "Gafas"    -> "\uD83D\uDD76";
            case "Collares" -> "\uD83D\uDCFF";
            case "Gorras"   -> "\uD83E\uDDE2";
            case "Pulseras" -> "\uD83D\uDCFF";
            case "Anillos"  -> "\uD83D\uDC8D";
            case "Relojes"  -> "\u231A";
            default         -> "\uD83D\uDED2";
        };

        JLabel img = new JLabel(emoji);
        img.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 26));
        img.setPreferredSize(new Dimension(34, 34));

        JPanel info = new JPanel(new GridLayout(2, 1));
        info.setOpaque(false);
        JLabel nombre = new JLabel(p.getNombre());
        nombre.setFont(new Font("Segoe UI", Font.BOLD, 11));
        JLabel precio = new JLabel("$" + String.format("%,.0f", p.getPrecio()));
        precio.setFont(new Font("Segoe UI", Font.BOLD, 12));
        precio.setForeground(PURPLE);
        info.add(nombre); info.add(precio);

        JButton btnQ = new JButton("\u2715");
        btnQ.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnQ.setForeground(RED);
        btnQ.setBorder(null);
        btnQ.setContentAreaFilled(false);
        btnQ.setFocusPainted(false);
        btnQ.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnQ.addActionListener(e -> quitarDelCarrito(p));

        item.add(img,  BorderLayout.WEST);
        item.add(info, BorderLayout.CENTER);
        item.add(btnQ, BorderLayout.EAST);
        return item;
    }

    // =====================================================================
    // LOGICA
    // =====================================================================
    private void agregarAlCarrito(Producto p) {
        try {
            p.comprar(1);
            carrito.agregarProducto(p);
            actualizarCarritoUI();
            actualizarProductos();
        } catch (StockInsuficienteException e) {
            JOptionPane.showMessageDialog(this, "\u274C " + e.getMessage(),
                "Stock insuficiente", JOptionPane.WARNING_MESSAGE);
        } catch (CantidadInvalidaException e) {
            JOptionPane.showMessageDialog(this, "\u274C " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void quitarDelCarrito(Producto p) {
        try {
            carrito.eliminarProducto(p);
            p.setStock(p.getStock() + 1);
            actualizarCarritoUI();
            actualizarProductos();
        } catch (ProductoNoEncontradoException e) {
            JOptionPane.showMessageDialog(this, "\u274C " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void realizarPedido() {
        ArrayList<Producto> items = carrito.getProductos();
        if (items.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "\u26A0 El carrito esta vacio.", "Carrito vacio",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            double total = carrito.calcularTotal();
            ArrayList<Producto> copia = new ArrayList<>(items);
            Pedido pedido = new Pedido(
                cliente.getHistorialPedidos().size() + 1001, cliente, copia);
            cliente.agregarPedido(pedido);
            carrito.vaciarCarrito();
            actualizarCarritoUI();
            JOptionPane.showMessageDialog(this,
                "\u2705 \u00A1Pedido #" + pedido.getIdPedido() + " realizado!\n" +
                "Total: $" + String.format("%,.0f", total),
                "Pedido realizado", JOptionPane.INFORMATION_MESSAGE);
        } catch (CarritoVacioException e) {
            JOptionPane.showMessageDialog(this,
                "\u274C " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void verHistorial() {
        var pedidos = cliente.getHistorialPedidos();
        if (pedidos.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "No tienes pedidos registrados aun.", "Mis Pedidos",
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        StringBuilder sb = new StringBuilder("=== Historial de Pedidos ===\n\n");
        for (Pedido p : pedidos) {
            sb.append("Pedido #").append(p.getIdPedido())
              .append(" -- Total: $").append(String.format("%,.0f", p.getTotal())).append("\n");
            for (Producto prod : p.getProductos())
                sb.append("  - ").append(prod.getNombre())
                  .append(" -- $").append(String.format("%,.0f", prod.getPrecio())).append("\n");
            sb.append("\n");
        }
        JTextArea area = new JTextArea(sb.toString());
        area.setEditable(false);
        area.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        JOptionPane.showMessageDialog(this,
            new JScrollPane(area), "Mis Pedidos", JOptionPane.PLAIN_MESSAGE);
    }

    private void verPerfil() {
        JOptionPane.showMessageDialog(this,
            "\uD83D\uDC64 Perfil del Cliente\n\n" +
            "Nombre:    " + cliente.getNombre() + "\n" +
            "Correo:    " + cliente.getCorreo() + "\n" +
            "Telefono:  " + cliente.getTelefono() + "\n" +
            "Direccion: " + cliente.getDireccion() + "\n" +
            "Rol:       " + cliente.getRol(),
            "Mi Perfil", JOptionPane.INFORMATION_MESSAGE);
    }

    private void confirmarSalir() {
        int r = JOptionPane.showConfirmDialog(this,
            "\u00BFDeseas cerrar la aplicacion?", "Cerrar",
            JOptionPane.YES_NO_OPTION);
        if (r == JOptionPane.YES_OPTION) System.exit(0);
    }

    // =====================================================================
    // ACTUALIZAR VENTANA
    // =====================================================================
    private void actualizarProductos() {
        if (panelProductos == null) return;
        panelProductos.removeAll();
        String busq = txtBuscar != null ? txtBuscar.getText().toLowerCase().trim() : "";
        if (busq.equals("buscar producto...")) busq = "";
        for (Producto p : inventario) {
            boolean matchCat  = categoriaActual.equals("Todos") || p.getTipo().equals(categoriaActual);
            boolean matchBusc = busq.isEmpty() || p.getNombre().toLowerCase().contains(busq);
            if (matchCat && matchBusc)
                panelProductos.add(crearTarjetaProducto(p));
        }
        panelProductos.revalidate();
        panelProductos.repaint();
    }

    private void actualizarCarritoUI() {
        if (panelCarritoItems == null) return;
        panelCarritoItems.removeAll();
        ArrayList<Producto> items = carrito.getProductos();
        for (Producto p : items) {
            panelCarritoItems.add(crearItemCarrito(p));
            panelCarritoItems.add(Box.createVerticalStrut(6));
        }
        if (lblContadorCarrito != null)
            lblContadorCarrito.setText(String.valueOf(items.size()));
        try {
            double total = items.isEmpty() ? 0 : carrito.calcularTotal();
            if (lblTotal != null)
                lblTotal.setText("$" + String.format("%,.0f", total));
        } catch (CarritoVacioException e) {
            if (lblTotal != null) lblTotal.setText("$0");
        }
        panelCarritoItems.revalidate();
        panelCarritoItems.repaint();
    }

    // =====================================================================
    // BOTONES
    // =====================================================================
    private JButton crearBotonPrimario(String texto) {
        JButton btn = new JButton(texto) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(!isEnabled() ? new Color(200,200,200)
                    : getModel().isRollover() ? PURPLE_DARK : PURPLE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                super.paintComponent(g);
            }
        };
        btn.setFont(new Font("Segoe UI Emoji", Font.BOLD, 13));
        btn.setForeground(WHITE);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setPreferredSize(new Dimension(0, 38));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private JButton crearBotonVerde(String texto) {
        JButton btn = new JButton(texto) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? new Color(21,128,61) : GREEN);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                super.paintComponent(g);
            }
        };
        btn.setFont(new Font("Segoe UI Emoji", Font.BOLD, 13));
        btn.setForeground(WHITE);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private JButton crearBotonSecundario(String texto) {
        JButton btn = new JButton(texto) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? PURPLE_LIGHT : WHITE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.setColor(BORDER_CLR);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 8, 8);
                super.paintComponent(g);
            }
        };
        btn.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 12));
        btn.setForeground(TEXT_DARK);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setPreferredSize(new Dimension(0, 36));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private JButton crearBotonMenuSimple(String icono, String texto) {
        JButton btn = new JButton(icono + "  " + texto) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? PURPLE_LIGHT : WHITE);
                g2.fillRect(0, 0, getWidth(), getHeight());
                super.paintComponent(g);
            }
        };
        btn.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 13));
        btn.setForeground(TEXT_DARK);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorder(new EmptyBorder(11, 20, 11, 20));
        btn.setMaximumSize(new Dimension(220, 44));
        btn.setPreferredSize(new Dimension(220, 44));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private JToggleButton crearBotonCategoria(String texto) {
        JToggleButton btn = new JToggleButton("  " + texto) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(WHITE);
                g2.fillRect(0, 0, getWidth(), getHeight());
                int cx = 22, cy = getHeight() / 2, r = 7;
                g2.setColor(BORDER_CLR);
                g2.drawOval(cx - r, cy - r, r * 2, r * 2);
                if (isSelected()) {
                    g2.setColor(PURPLE);
                    g2.fillOval(cx - r, cy - r, r * 2, r * 2);
                    g2.setColor(PURPLE);
                } else { g2.setColor(TEXT_DARK); }
                super.paintComponent(g);
            }
        };
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorder(new EmptyBorder(6, 38, 6, 16));
        btn.setMaximumSize(new Dimension(220, 34));
        btn.setPreferredSize(new Dimension(220, 34));
        return btn;
    }

    // =====================================================================
    public static void main(String[] args) {
        SwingUtilities.invokeLater(DiavelPhamtom::new);
    }
}
